// Violetta Firyaridi
//
// CHWMXR
//
// Violetta Firyaridi
//
// 2018/10/12 01:47:06
//
// This solution was submitted and prepared by Violetta Firyaridi, CHWMXR for the
// Violetta Firyaridi assignment of the Practical software engineering I. course.
//
// I declare that this solution is my own work.
//
// I have not copied or used third party solutions.
//
// I have not passed my solution to my classmates, neither  made it public.
//
// Students’ regulation of Eцtvцs Lorбnd University (ELTE Regulations
// Vol. II. 74/C. § ) states that as long as a student presents another
// student’s work - or at least the significant part of it - as his/her own
// performance, it will count as a disciplinary fault. The most serious
// consequence of a disciplinary fault can be dismissal of the student from
// the University.

package planet;

import java.io.IOException;
import java.util.ArrayList;

public class Planet {
    public int days;
    public int numberOfPlants;
    public ArrayList<Plant> plants;

    public Planet(int days, ArrayList<Plant> plants) {
        this.days = days;
        this.numberOfPlants = plants.size();
        this.plants = plants;
    }

    public int sumNutrientLevel() {
        int sum = 0;
        for (Plant p : plants) {
            sum += p.nutrientLevel;
        }
        return sum;
    }

    public void deletePuffs() {
        for (int i = 0; i < this.plants.size(); i++) {
            if (this.plants.get(i).getClass() == Puffs.class) {
                this.plants.remove(this.plants.get(i));
                this.numberOfPlants--;
            }
        }
    }

    public void printInputData() {
        System.out.println("Input case:");
        System.out.println("Number of days to simulate: " + this.days + ", number of plants: " + this.numberOfPlants);
        for (Plant p : this.plants) {
            System.out.println("Name: " + p.name + ", Nutrient level: " + p.nutrientLevel);
        }
        System.out.println("=============================================================");
    }

    public void mainPlanetLogic() {
        int sumN = 0;
        int needForAlfa = 0;
        int needForDelta = 0;
        String radiationOfTheNextDay = "no radiation";

        printInputData();

        for (int j = 0; j < this.days; j++) {//go through the days
            System.out.println("Day " + (j + 1));
            System.out.println("Today's radiation is: " + radiationOfTheNextDay);

            for (int i = 0; i < this.numberOfPlants; i++) {//for every plant
                if (this.plants.get(i).isAlive()) { //whether the plant alive or not
                    switch (radiationOfTheNextDay) {
                        case "no radiation": {
                            this.plants.get(i).changeNutrientLevel(radiationOfTheNextDay);
                            break;
                        }
                        case "delta": {
                            this.plants.get(i).changeNutrientLevel(radiationOfTheNextDay);
                            break;
                        }

                        case "alfa": {
                            this.plants.get(i).changeNutrientLevel(radiationOfTheNextDay);
                            break;
                        }
                        default:
                            break;
                    }
                } else {
                    this.plants.remove(i);
                    this.numberOfPlants = this.plants.size();
                }
            }
            sumN = this.sumNutrientLevel();//sum current nutrients level

            if (sumN > 10) {
                deletePuffs();
            }

            //count need for radiation on next day
            needForAlfa = 10 - sumN;
            if (sumN < 5) {
                needForDelta += 4;
            }
            if (sumN > 5 && sumN < 10) {
                needForDelta++;
            } else needForDelta = 0;

            //change the radiationOfTheNextDay
            if (needForAlfa >= needForDelta + 3) {
                radiationOfTheNextDay = "alfa";
            }
            if (needForDelta >= needForAlfa + 3) {
                radiationOfTheNextDay = "delta";
            } else radiationOfTheNextDay = "no radiation";

            for (Plant p : this.plants) {
                System.out.println("Name: " + p.name + ", Nutrient level: " + p.nutrientLevel);
            }
            System.out.println("=============================================================");

        }
        System.out.println("Survivors:");
        for (Plant p : this.plants) {
            System.out.println(p.name);
        }
    }
}
