// Violetta Firyaridi
//
// CHWMXR
//
// Violetta Firyaridi
//
// 2018/10/12 01:47:06
//
// This solution was submitted and prepared by Violetta Firyaridi, CHWMXR for the
// Violetta Firyaridi assignment of the Practical software engineering I. course.
//
// I declare that this solution is my own work.
//
// I have not copied or used third party solutions.
//
// I have not passed my solution to my classmates, neither  made it public.
//
// Students’ regulation of Eцtvцs Lorбnd University (ELTE Regulations
// Vol. II. 74/C. § ) states that as long as a student presents another
// student’s work - or at least the significant part of it - as his/her own
// performance, it will count as a disciplinary fault. The most serious
// consequence of a disciplinary fault can be dismissal of the student from
// the University.

package planet;

public class Plant {
    public String name;
    public int nutrientLevel;
    protected boolean living;

    public Plant(String name, int nutrientLevel, boolean living) {
        this.name = name;
        this.nutrientLevel = nutrientLevel;
        this.living = living;
    }

    public boolean isAlive() {
        if (this.nutrientLevel <= 0) living = false;
        return living;
    }

    public void changeNutrientLevel(String typeOfRadiation) {
    }
}
