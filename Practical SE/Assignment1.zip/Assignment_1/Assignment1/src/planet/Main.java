// Violetta Firyaridi
//
// CHWMXR
//
// Violetta Firyaridi
//
// 2018/10/12 01:47:06
//
// This solution was submitted and prepared by Violetta Firyaridi, CHWMXR for the
// Violetta Firyaridi assignment of the Practical software engineering I. course.
//
// I declare that this solution is my own work.
//
// I have not copied or used third party solutions.
//
// I have not passed my solution to my classmates, neither  made it public.
//
// Students’ regulation of Eцtvцs Lorбnd University (ELTE Regulations
// Vol. II. 74/C. § ) states that as long as a student presents another
// student’s work - or at least the significant part of it - as his/her own
// performance, it will count as a disciplinary fault. The most serious
// consequence of a disciplinary fault can be dismissal of the student from
// the University.

package planet;

import org.omg.CORBA.DynAnyPackage.InvalidValue;

import java.io.*;
import java.lang.Exception;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static Planet readFileInfo(String filePath)
            throws InvalidInputException, FileNotFoundException,
            NegativeArraySizeException, NullPointerException,
            IOException, InvalidValue {

        FileInputStream fstream = new FileInputStream(filePath);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        String strLine;
        int numberOfPlants = 0;
        int numberOfDays = 0;
        int count = 0;

        numberOfPlants = Integer.parseInt((strLine = br.readLine()).split(" ")[0]);
        String[] plantInfo = new String[numberOfPlants];

        while ((strLine = br.readLine()) != null) {
            try{
                if (count < numberOfPlants) {
                    plantInfo[count] = strLine;
                } else if (count == numberOfPlants) {
                    numberOfDays = Integer.parseInt(strLine.split(" ")[0]);
                }
                count++;
            }catch (NumberFormatException e) {
                System.out.println("Invalid input!");
                System.exit(-1);
            }

        }

        if (numberOfDays <= 0 || numberOfPlants <= 0) {
            System.out.println("Check the number of days/plants given in a file!");
            throw new InvalidInputException();
        }

        ArrayList<Plant> plantsOnPlanet = new ArrayList();
        for (int i = 0; i < plantInfo.length; i++) {
            String name = plantInfo[i].split(" ")[0];
            int nutrientLevel = Integer.parseInt(plantInfo[i].split(" ")[2]);
            if (nutrientLevel <= 0) {
                System.out.println("Nutrient level of the " + name + " cannot be less then zero!");
                throw new InvalidInputException();
            }

            switch (plantInfo[i].split(" ")[1]) {
                case "p": {//puffs
                    Plant puff = new Puffs(name, nutrientLevel, true);
                    plantsOnPlanet.add(puff);
                    break;
                }
                case "b": {//parabush
                    Plant parabush = new Parabush(name, nutrientLevel, true);
                    plantsOnPlanet.add(parabush);
                    break;
                }
                case "d": {//deltatree
                    Plant deltatree = new Deltatree(name, nutrientLevel, true);
                    plantsOnPlanet.add(deltatree);
                    break;
                }
                default: {
                    throw new InvalidInputException();
                }
            }
        }
        Planet planet = new Planet(numberOfDays, plantsOnPlanet);
        return planet;

    }

    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        System.out.println("Write the name of the file with the info: ");
        String filePath = in.next();

        try {
            Planet plantsPlanet = readFileInfo(filePath);
            plantsPlanet.mainPlanetLogic();
        } catch (InvalidInputException ex) {
            System.out.println("Invalid input!");
            System.exit(-1);
        } catch (FileNotFoundException e) {//wrong path
            System.out.println("File not found!");
            System.exit(-1);
        } catch (NullPointerException e) {//none info in a file
            System.out.println("Print the valid information inside the file, it cannont be none");
            System.exit(-1);
        } catch (IOException e) {//the connection was lost
            System.out.println("The file cannot be read");
        }

    }
}
